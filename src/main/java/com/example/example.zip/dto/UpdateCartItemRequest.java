package com.example.dto;

public class UpdateCartItemRequest {
    private Integer quantity;

    // Getters and Setters
    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}