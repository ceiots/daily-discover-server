package com.example.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.model.Tag;

/**
 * 商品标签数据库操作
 */
public interface TagMapper extends BaseMapper<Tag> {

} 