package com.example.model;

import lombok.Data;
import com.fasterxml.jackson.annotation.JsonInclude;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PurchaseNotice {
    private String title;
    private String content;
    private Integer sort;
} 